gc = {"type": "GeometryCollection",
              "geometries": [{"type": "Point",
                                      "coordinates": [-89.33, 30.0]},
                             {"type": "LineString",
                                      "coordinates": [[-89.33, 30.30],
                                                      [-89.36, 30.28]]}]}
print(gc)
