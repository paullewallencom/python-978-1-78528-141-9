"""Convert lat/lon to utm"""
import utm
print(utm.from_latlon(48.55199390882121, 8.725555729071763))
